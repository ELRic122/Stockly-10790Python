# Stockly-10790Python
Stockly - Projeto Programação ⇾ Gestão Inventário

# Links de trabalho:
**Docs:** https://docs.google.com/document/d/11_MzBAp5Jw3MxyjOu0yr3ZExloxyqeURfewOYpecQNc/edit?tab=t.0

**Canva:** https://www.canva.com/design/DAGkDWEMrTE/dF5K80rTtfFWIDSK6G6bnQ/edit

**Figma:** https://www.figma.com/design/LTtzdOl46O2TJxqjA41Gue/Untitled?node-id=0-1&p=f&t=QGhiTUuR7azmQ92j-0


**Notas:**

Colocar o programa online, para qualquer pessoa puder utilizar? Pode haver problemas com a base de dados? Pesquisar sobre.

Fazer um programa “bonito” e não o hospedar, o cliente baixa o programa e a base de dados e criada e guardada localmente no PC e depois o mesmo pode fazer o upload dela para um serviço de cloud (tira a compatibilidade entre diversos dispositivos).

Run Python scripts in the browser(https://medium.com/codex/run-python-scripts-in-the-web-browser-afb09c4b212f) ⇾ incorporar código Python num website.

Automate the boring stuff (https://automatetheboringstuff.com/) ⇾ automatização em Python, projetos reais.

PyQt6 website oficial (https://pypi.org/project/PyQt6/) ⇾ necessário para tornar o programa executável.

Exemplos PyQt GitHub (https://github.com/pyqt/examples) ⇾ Exemplos PyQt.

Pushing changes without fucking the master branch (https://gist.github.com/abelcallejo/a7f35d9277417560b4c5a7178f8677d1) ⇾ criar branches sem rebentar o código principal.

Reddit Documentacao Tecnica (https://www.reddit.com/r/technicalwriting/comments/113mh5p/technical_documentation_templatessamplesexamples/?rdt=64523) ⇾ Documentação Técnica
